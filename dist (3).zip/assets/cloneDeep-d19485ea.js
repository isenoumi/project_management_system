import{b as o}from"./_baseClone-2c6dfa75.js";var r=1,n=4;function a(e){return o(e,r|n)}export{a as c};
