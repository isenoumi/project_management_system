import{b as o}from"./_baseClone-39808c29.js";var r=1,n=4;function a(e){return o(e,r|n)}export{a as c};
