import{b7 as t}from"./index-6ca2f838.js";const e=(...c)=>s=>{c.forEach(o=>{t(o)?o(s):o.value=s})};export{e as c};
