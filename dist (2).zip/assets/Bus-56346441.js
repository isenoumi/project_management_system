class l{constructor(){this.list={}}emit(t,...s){this.list[t].forEach(i=>{i.apply(this,s)})}on(t,s){let e=this.list[t]||[];e.push(s),this.list[t]=e}}const h=new l;export{h as B};
