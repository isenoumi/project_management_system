import{b7 as t}from"./index-d6b3570f.js";const e=(...c)=>s=>{c.forEach(o=>{t(o)?o(s):o.value=s})};export{e as c};
