import{b as o}from"./_baseClone-1c2f01e5.js";var r=1,n=4;function a(e){return o(e,r|n)}export{a as c};
